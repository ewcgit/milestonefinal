package com.freshapples.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshapples.model.*;

import com.freshapples.services.MovieService;

@RestController
@RequestMapping("/api/v1/orders")
public class MovieRestController {
    MovieService service;
    
    @Autowired
    public MovieRestController(MovieService service){
        super();
        this.service = service;
    }
    
    @GetMapping("/")
    public List<Movie> showAllMovies(){
        List<Movie> movies = service.getAllMovies();
        return movies;
    }   
    @GetMapping("/{id}")
    public Movie showMovie(@PathVariable(name="id") long id){
        Movie movie = service.getMovieById(id);
        return movie;
    }
}